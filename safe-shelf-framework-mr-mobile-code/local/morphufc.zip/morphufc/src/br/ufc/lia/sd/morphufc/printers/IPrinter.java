package br.ufc.lia.sd.morphufc.printers;

public interface IPrinter {

	public void clientPrinter(String msg);
	public void serverPrinter(String msg);
}
